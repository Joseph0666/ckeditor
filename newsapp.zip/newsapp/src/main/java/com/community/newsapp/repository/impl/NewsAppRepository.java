package com.community.newsapp.repository.impl;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.community.newsapp.domain.News;

@Repository
public interface NewsAppRepository extends CrudRepository<News,Integer> {

}
