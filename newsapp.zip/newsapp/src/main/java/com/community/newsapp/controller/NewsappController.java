package com.community.newsapp.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.community.newsapp.domain.News;
import com.community.newsapp.service.NewsappService;

@RestController
public class NewsappController {

	@Autowired
	NewsappService newsAppService;   
	
   
   @GetMapping("/getLatestNews")
	public  List<News> getNewsData() {
	  List<News> data = newsAppService.getNews();
	  return data;
	}
   
   @GetMapping("/saveLatestNews")
  	public String saveNewsData() {
  	  newsAppService.saveNews();
  	  return "saved";
  	}
   
   @GetMapping("/getLatestNewsFromDB")
	public  List<News> getLatestNewsFromDB() {
	  List<News> data = newsAppService.getAllNews();
	  return data;
	}
  
}
