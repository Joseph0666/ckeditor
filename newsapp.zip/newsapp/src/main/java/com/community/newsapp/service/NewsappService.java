package com.community.newsapp.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.community.newsapp.domain.News;
import com.community.newsapp.repository.impl.NewsAppRepository;
import java.util.*;
import org.json.*;  


@Service
public class NewsappService {
	@Autowired
	RestTemplate restTemplate;
	
	@Autowired
	NewsAppRepository newsAppRepository;
	
   public final static String apiCode = "pub_751964721489937f6c95f4dccb09936a749";
   public final static String newsURI = "https://newsdata.io/api/1/news?apikey="+apiCode;
	
   public final static String countryCode = "in";
   
	public List<News> getNews() {
		  HttpHeaders headers = new HttpHeaders();
	      headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	      HttpEntity <String> entity = new HttpEntity<String>(headers);
	      
	      String data =  restTemplate.exchange(newsURI, HttpMethod.GET, entity, String.class).getBody();
//	      String data = "{status:'success',results:[{title:'test'}]}";
	      List<News> newsList = convertJSONToObject(data.toString());
		  return newsList;
	}
	
	@Transactional
	public void saveNews() {
		List<News> newsList = getNews();

		for(News news: newsList) {
			newsAppRepository.save(news);
		}
		
	}
	
	public List<News> getAllNews(){
		List<News> newsList = (List<News>) newsAppRepository.findAll();
		return newsList;
	}
	
	private List<News> convertJSONToObject(String str){
		List<News> newsList = new LinkedList<>();
		JSONObject jsonObject = new JSONObject(str);
		System.out.println("jsonObject--->>"+str);
		String status = jsonObject.getString("status");
		if(status.equals("success")) {
			JSONArray jsonarray = jsonObject.getJSONArray("results"); 
			for(int i=0; i < jsonarray.length(); i++)   
			{  
			JSONObject object = jsonarray.getJSONObject(i);  
			String title = object.getString("title");
			String link = object.getString("link");
			String keywords = object.getString("keywords");
			String description = object.getString("description");
			String content = object.getString("content");
			String pubDate = object.getString("pubDate");
			String creator = object.getString("creator");
			String video_url = object.getString("video_url");
			String image_url = object.getString("image_url");
			String source_id = object.getString("source_id");
			News news = new News(title,link,keywords,creator,video_url,description,content,pubDate,image_url,source_id);
			newsList.add(news);
			}
		}
		  
		return newsList;
		
	}
}
