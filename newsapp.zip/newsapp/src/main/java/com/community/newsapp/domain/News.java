package com.community.newsapp.domain;

import javax.persistence.*;
import javax.persistence.Table;

@Entity
@Table(name="news")
public class News {
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	long id;
	@Column(name= "title")  
	String title;
	@Column(name= "link")
	String link;
	@Column(name= "keywords")
	String keywords;
	@Column(name= "creator")
	String creator;
	@Column(name= "videoURL")
	String videoURL;
	@Column(name= "description")
	String description;
	@Column(name= "content")
	String content;
	@Column(name= "pubDate")
	String pubDate;
	@Column(name= "imgURL")
	String imgURL;
	@Column(name= "source")
	String source;
	
	public News() {
		
	}
	
	public News(String title, String link, String keywords, String creator, String videoURL, String description,
			String content, String pubDate, String imgURL, String source) {
		super();
		this.title = title;
		this.link = link;
		this.keywords = keywords;
		this.creator = creator;
		this.videoURL = videoURL;
		this.description = description;
		this.content = content;
		this.pubDate = pubDate;
		this.imgURL = imgURL;
		this.source = source;
	}
	
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	public String getKeywords() {
		return keywords;
	}
	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}
	public String getCreator() {
		return creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public String getVideoURL() {
		return videoURL;
	}
	public void setVideoURL(String videoURL) {
		this.videoURL = videoURL;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getPubDate() {
		return pubDate;
	}
	public void setPubDate(String pubDate) {
		this.pubDate = pubDate;
	}
	public String getImgURL() {
		return imgURL;
	}
	public void setImgURL(String imgURL) {
		this.imgURL = imgURL;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	
	
}
