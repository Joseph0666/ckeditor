package com.community.newsapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewsappApplicationTests {

	@Test
	void contextLoads() {
	}

}
